/*
App.PostsSingleView = Ember.View.extend({
	templateName: 'posts/single'
});

App.PostsView = Ember.CollectionView.extend({
	templateName: 'posts'
});
*/
