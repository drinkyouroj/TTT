/*
App.PostsSingleController = Ember.ObjectController.extend({
	
});

App.PostsController = Ember.ArrayController.extend({
	
});
*/