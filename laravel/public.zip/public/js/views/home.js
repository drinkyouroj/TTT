$(window).load(function() {
	$('#top-featured').packery({
	  itemSelector: '.featured-item',
	  gutter: 4
	});
});
